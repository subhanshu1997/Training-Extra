﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import{HttpClientModule} from "@angular/common/http";
import {FormsModule} from "@angular/forms"
import {RouterModule,Routes} from '@angular/router';
import {AddEmployeeComponent} from './app.addemployee';
import {SearchEmployeeComponent} from './app.searchemployee';
import {ShowEmployeeComponent} from './app.showemployee';
import{MyPipe} from './app.myownpipeline'
const routes:Routes=[
    {path:'add',component:AddEmployeeComponent},
    {path:'show',component:ShowEmployeeComponent},
    {path:'show/:id',component:ShowEmployeeComponent},
    {path:'search',component:SearchEmployeeComponent},
    {path:'',redirectTo:'show',pathMatch:'full'}
]
@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule,
        RouterModule.forRoot(routes)
        
    ],
    declarations: [
        AppComponent,
        AddEmployeeComponent,
        SearchEmployeeComponent,
        ShowEmployeeComponent,
        MyPipe
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }