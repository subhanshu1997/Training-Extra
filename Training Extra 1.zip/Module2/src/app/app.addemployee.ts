import { Component, OnDestroy } from "@angular/core";
import { EmployeeService } from "./app.employeeservice";
import { Router } from "@angular/router";
@Component({
    selector:'add-employee',
    templateUrl:'add-employee.html'
})
export class AddEmployeeComponent implements OnDestroy{
    ngOnDestroy(): void {
        console.log("Destroyed")
    }
    constructor(private service:EmployeeService,private router:Router){}
    arr:any[]=[]
    empId:number
    empName:string
    empSalary:number
    empDepartment:string
    status:boolean
    empty:boolean=true
    // change(){
    //     this.arr[0]={empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment}
    //     this.status=!this.status
    //     this.empty=false
    // }
    addEmployee(){
        this.arr[0]=({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment})
        if(this.service.addEmployee(this.arr)==true){
            this.router.navigate(['show'])
        }
    }
}