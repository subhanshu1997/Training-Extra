import { Component } from "@angular/core";
import { EmployeeService } from "./app.employeeservice";
import { Router } from "@angular/router";

@Component({
    selector:'search-employee',
    templateUrl:'search-employee.html'
})
export class SearchEmployeeComponent{
    constructor(private service:EmployeeService,private router:Router){}
    empId:number
    empId1:number
    empName:string
    empSalary:number
    empDepartment:string 
    data:any
    status:boolean=false  
    public message:string

    showEmployee(){
            // this.data=this.service.showEmployee(this.empId)
            // this.empId1=this.data.empId
            // this.empName=this.data.empName
            // this.empSalary=this.data.empSalary
            // this.empDepartment=this.data.empDepartment
            // this.status=true
            // this.message = this.empId+" "+this.empName+" "+this.empSalary+" "+this.empDepartment}
            this.router.navigate(['show',this.empId])
    }
}