import { Injectable, OnChanges, SimpleChanges, Input, OnDestroy } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { of, Observable } from "rxjs";
import { ShowEmployeeComponent } from "./app.showemployee";

@Injectable({
    providedIn:'root'
})
export class EmployeeService implements OnDestroy{
    ngOnDestroy(): void {
        console.log("Service Destroyed")
    }
    status:boolean=false
    emparr:any[]=[
        {empId:1005,empName:"Subhanshu",empSalary:500000,empDepartment:"java"},
        {empId:1006,empName:"Subhanshu",empSalary:500000,empDepartment:"java"}
    ]
    constructor(private http:HttpClient){

    }
    getAllEmployee():any[]{
        //  return this.http.get("assets/employee.json");
        return this.emparr
    }
  addEmployee(arr:any[]):boolean{
    this.emparr.push(arr[0])
    return true
  }
  showEmployee(id:number):any{
      for(let data of this.emparr){
        if(id==data.empId){
            return data
        }
      }
  }

}