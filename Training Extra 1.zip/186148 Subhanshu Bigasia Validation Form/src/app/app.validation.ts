import { Component } from "@angular/core";

@Component({
    selector:'app-validation',
    templateUrl:'app.validation.html',
    styleUrls:['app.validate.css']
})
export class Validation{
    // Declaring Types
    name:string
    address:string
    pinCode:number
    validationStatus:string="INVALID"
    info:string="{\"name\":\"\",\"address\":\"\",\"PinCode\":\"\" }"
    status:boolean=false
    //Validating From Method
    validateForm(){
        //Setting validation status to valid
        this.validationStatus="VALID"
        //Setting User Info
        this.info="{\"name\":\""+this.name+"\",\"address\":\""+this.address+"\",\"PinCode\":\""+this.pinCode+"\"}"
        this.status=true
    }

}